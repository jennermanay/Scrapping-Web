package pe.edu.monitoreo;

import static com.google.common.base.Preconditions.checkNotNull;
import java.util.Set;

/** Application controller for product monitoring; has no dependency on JavaFX controls. */
public final class MonitoringController {
    private final Store store;
    private final IExtractorFuente extractor;
    private final ISearchFuente search;
    public MonitoringController(Store store,IExtractorFuente extractor,ISearchFuente search){this.store=checkNotNull(store);this.extractor=checkNotNull(extractor);this.search=checkNotNull(search);}
    /** Loads a stable view model. Authentication is enforced by Store. */
    public DashboardModel dashboard()throws Exception {
        var granted=store.permissions();boolean products=granted.stream().anyMatch(m->java.util.Set.of(Module.INICIO,Module.PRODUCTOS,Module.MONITOREO,Module.FICHAS,Module.EXTRACCION,Module.REPORTES).contains(m));boolean sources=products||granted.contains(Module.FUENTES);boolean links=granted.stream().anyMatch(m->java.util.Set.of(Module.INICIO,Module.PRODUCTOS,Module.MONITOREO,Module.FICHAS,Module.EXTRACCION).contains(m));boolean alerts=granted.stream().anyMatch(m->java.util.Set.of(Module.INICIO,Module.ALERTAS,Module.REPORTES).contains(m));boolean monitoring=granted.stream().anyMatch(m->java.util.Set.of(Module.INICIO,Module.MONITOREO,Module.EXTRACCION).contains(m));
        return new DashboardModel(products?store.products():java.util.List.of(),sources?store.sources():java.util.List.of(),links?store.links():java.util.List.of(),alerts?store.alerts():java.util.List.of(),monitoring?store.monitoringSettings():java.util.Map.of(),granted.contains(Module.ROLES)||granted.contains(Module.USUARIOS)?store.roles():java.util.List.of(),granted);
    }
    /** Saves one product's source selection atomically and reloads the view model. */
    public DashboardModel configure(long product,Set<Long> sources,boolean scheduled)throws Exception {store.selectProductSources(product,sources,scheduled);return dashboard();}
    public DashboardModel configure(long product,Set<Long> sources,boolean scheduled,int minutes)throws Exception {store.selectProductSources(product,sources,scheduled,minutes);return dashboard();}
    public ProductScraping.Result extract(long product,long source)throws Exception {return new ProductScraping(store,extractor,search).run(product,source);}
    public ProductScraping.Result extractScheduled(long product)throws Exception {return new ProductScraping(store,extractor,search).run(product,0,true);}
    /** Runs the enabled sources; a failure in one does not cancel other sources. */
    public ProductScraping.Result extract(long product)throws Exception {return new ProductScraping(store,extractor,search).run(product);}
    /** Requires human evidence before saving homologation, comparison and alert. */
    public Economics.Result confirmAndCompare(long candidate,String evidence)throws Exception {return store.confirmAndCompare(candidate,evidence);}
}
