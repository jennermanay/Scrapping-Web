package pe.edu.monitoreo;

import java.math.BigDecimal;
import java.sql.*;
import java.time.*;
import java.util.*;
import com.google.gson.Gson;
import pe.edu.monitoreo.dao.*;

/** Repository and transactional application boundary. Every operation checks the session. */
public final class Store {
    public record User(long id,String username,String name,String role) { public boolean admin(){return role.equals("ADMIN");} @Override public String toString(){return username+" · "+name+" · "+role;} }
    public record Product(long id,String code,String name,String brand,String model,String presentation,String capacity,String category,String keywords,BigDecimal cost,BigDecimal price,boolean active) {
        public String attributes(){return String.join(" · ",brand,model,presentation,capacity);}
        @Override public String toString(){return code+" · "+name+(active?"":" [INACTIVO]");}
    }
    public record Source(long id,String name,String url,String titleSelector,String priceSelector,String titleAttribute,String priceAttribute,String strategy,int interval,int validity,boolean active) {
        @Override public String toString(){return name+" · "+strategy+(active?"":" [INACTIVA]");}
    }
    public record Link(long id,long productId,long sourceId,String product,String source,String url,String condition,boolean scheduled,boolean active,boolean reference,boolean search) {
        @Override public String toString(){return "#"+id+" · "+product+" / "+source+(reference?" [PRECIO PROPIO]":"")+(search?" [BÚSQUEDA AUTOMÁTICA]":"")+(scheduled?" [PROGRAMADO]":"")+(active?"":" [INACTIVO]");}
    }
    public record ComparisonSnapshot(long id,BigDecimal own,BigDecimal cost,BigDecimal external,String alertType){public Economics.Result result(){return Economics.compare(cost,own,external);}}
    public record Candidate(long id,String title,BigDecimal price,String url,String status,String condition,OffsetDateTime date,String evidence,ComparisonSnapshot comparison,String source,long sourceId) {
        @Override public String toString(){return "#"+id+" · "+title+" · S/ "+price+" · "+status+" · "+date;}
    }
    public record AlertItem(long id,String product,String type,String status,String note) { @Override public String toString(){return "#"+id+" · "+product+" · "+type+" · "+status+" · "+note;} }
    public record Role(String code,String name,boolean active,Set<Module> modules){public Role{modules=Set.copyOf(modules);}@Override public String toString(){return name+(active?"":" [INACTIVO]");}}
    public record Homologated(long id,long productId,long sourceId,String product,String source,String url,String title,BigDecimal price,String state,String reason,OffsetDateTime approved,OffsetDateTime checked){}
    public record MonitoringSettings(int minutes,boolean scheduled){}
    public record AlertDetail(long id,String product,String source,String type,String status,BigDecimal own,BigDecimal external,BigDecimal difference,String url,OffsetDateTime date,long productId,BigDecimal currentCost,BigDecimal currentPrice,PriceRecord decision,BigDecimal previousPrice,BigDecimal priceChange){}
    public record PriceRecord(String action,BigDecimal before,BigDecimal after,BigDecimal cost,BigDecimal profit,BigDecimal margin,String note,OffsetDateTime date){}
    private final ProductDao productDao=new JdbcProductDao();
    private final SourceDao sourceDao=new JdbcSourceDao();
    private volatile Config.Database connection;
    private final boolean fromFile;
    private volatile User session;
    public Store(){fromFile=true;}
    public Store(String url,String user,String password){connection=new Config.Database(url,user,password,5,15);fromFile=false;}
    Store(Config.Database settings){connection=settings;fromFile=false;}
    public synchronized void reloadConfiguration()throws SQLException {
        if(!fromFile)return;
        session=null;connection=null;
        try {connection=Config.database();}catch(Exception e){throw new SQLException(e.getMessage(),e);}
    }
    Connection open() throws SQLException {
        if(connection==null)reloadConfiguration();var settings=connection;
        var properties=new Properties();properties.setProperty("user",settings.user());properties.setProperty("password",settings.password());
        properties.setProperty("connectTimeout",""+settings.connectTimeout());properties.setProperty("socketTimeout",""+settings.socketTimeout());
        if(!settings.schema().isBlank())properties.setProperty("currentSchema",settings.schema());
        var c=DriverManager.getConnection(settings.url(),properties);c.setNetworkTimeout(Runnable::run,settings.socketTimeout()*1000);return c;
    }
    public String testConnection()throws SQLException {try(var c=open()){if(!c.isValid(3))throw new SQLException("La conexión no respondió.");return "Conexión correcta · PostgreSQL "+c.getMetaData().getDatabaseProductVersion()+" · base "+c.getCatalog()+" · usuario "+c.getMetaData().getUserName()+(connection.schema().isBlank()?"":" · esquema "+connection.schema());}}
    public User session(){return session;}
    private User require() throws SQLException {
        var u=session; if(u==null) throw new SecurityException("Inicia sesión.");
        try(var c=open();var s=prepare(c,"SELECT u.activo AND d.activo activo,u.rol FROM usuario u JOIN rol_definicion d ON d.codigo=u.rol WHERE u.id=?",u.id());var r=s.executeQuery()){
            if(!r.next()||!r.getBoolean(1)||!u.role().equals(r.getString(2))) {session=null;throw new SecurityException("La sesión perdió sus permisos. Ingresa nuevamente.");}
        }return u;
    }
    private User admin() throws SQLException {var u=require();if(!u.admin())throw new SecurityException("Se requiere rol administrador.");return u;}
    public Set<Module> permissions()throws SQLException {var actor=require();if(actor.admin())return Set.copyOf(EnumSet.allOf(Module.class));var result=EnumSet.noneOf(Module.class);try(var c=open();var q=prepare(c,"SELECT modulo FROM rol_permiso WHERE rol=?",actor.role());var r=q.executeQuery()){while(r.next())result.add(Module.valueOf(r.getString(1)));}return Set.copyOf(result);}
    public User requireModule(Module module)throws SQLException {if(!permissions().contains(module))throw new SecurityException("Sin permiso para "+module+".");return session;}
    private void requireAny(Module... modules)throws SQLException {var granted=permissions();if(Arrays.stream(modules).noneMatch(granted::contains))throw new SecurityException("Sin permiso para esta operación.");}
    public List<Role> roles()throws SQLException {requireAny(Module.ROLES,Module.USUARIOS);var result=new ArrayList<Role>();try(var c=open();var q=c.createStatement();var r=q.executeQuery("SELECT d.*,COALESCE(string_agg(p.modulo,','),'') permisos FROM rol_definicion d LEFT JOIN rol_permiso p ON p.rol=d.codigo GROUP BY d.codigo ORDER BY d.codigo")){while(r.next()){var modules=EnumSet.noneOf(Module.class);for(String value:r.getString("permisos").split(","))if(!value.isBlank())modules.add(Module.valueOf(value));result.add(new Role(r.getString("codigo"),r.getString("nombre"),r.getBoolean("activo"),modules));}}return result;}
    public void saveRole(String code,String name,boolean active,Set<Module> modules)throws SQLException {requireModule(Module.ROLES);code=required(code,"Código").toUpperCase(Locale.ROOT);name=required(name,"Nombre");if(!code.matches("[A-Z][A-Z0-9_]{1,39}"))throw new IllegalArgumentException("Código de rol inválido.");if(code.equals("ADMIN")&&(!active||!modules.containsAll(EnumSet.allOf(Module.class))))throw new IllegalArgumentException("Administrador conserva todos los módulos.");try(var c=open()){c.setAutoCommit(false);try{update(c,"INSERT INTO rol_definicion(codigo,nombre,activo) VALUES (?,?,?) ON CONFLICT(codigo) DO UPDATE SET nombre=excluded.nombre,activo=excluded.activo",code,name,active);update(c,"DELETE FROM rol_permiso WHERE rol=?",code);for(var module:modules)update(c,"INSERT INTO rol_permiso(rol,modulo) VALUES (?,?)",code,module.name());c.commit();}catch(SQLException|RuntimeException e){c.rollback();throw e;}}}
    public Map<Long,MonitoringSettings> monitoringSettings()throws SQLException {requireAny(Module.INICIO,Module.MONITOREO,Module.EXTRACCION);var result=new HashMap<Long,MonitoringSettings>();try(var c=open();var q=c.createStatement();var r=q.executeQuery("SELECT * FROM producto_monitoreo")){while(r.next())result.put(r.getLong("producto_id"),new MonitoringSettings(r.getInt("intervalo_min"),r.getBoolean("programado")));}return Map.copyOf(result);}
    public void initialize() throws Exception {
        try(var c=open()) {c.setAutoCommit(false);try(var lock=c.createStatement()){
                if(!connection.schema().isBlank()){
                    if(!connection.schema().matches("[a-z][a-z0-9_]{0,62}"))throw new IllegalArgumentException("Nombre de esquema inválido.");
                    lock.execute("CREATE SCHEMA IF NOT EXISTS \""+connection.schema()+"\"");
                }
                lock.execute("SELECT pg_advisory_xact_lock(729513)");}
            try { for(String file:List.of("/schema.sql","/migration-v2.sql","/migration-v3.sql","/migration-v4.sql","/migration-v5.sql","/migration-v6.sql","/migration-v7.sql","/migration-v8.sql","/migration-v9.sql"))try(var in=Store.class.getResourceAsStream(file);var s=c.createStatement()){
                if(in==null)throw new IllegalStateException("Falta "+file);s.execute(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));
            }c.commit();}catch(Exception e){c.rollback();throw e;}
        }
    }
    public boolean needsSetup() throws SQLException {try(var c=open();var s=c.createStatement();var r=s.executeQuery("SELECT NOT EXISTS(SELECT 1 FROM usuario)")){r.next();return r.getBoolean(1);}}
    public void setup(String username,String name,String password)throws SQLException {
        String hash=Passwords.hash(password);username=validUsername(username);name=required(name,"Nombre");
        try(var c=open()){c.setAutoCommit(false);try{
            try(var s=c.createStatement()){s.execute("SELECT pg_advisory_xact_lock(729514)");}
            try(var s=c.createStatement();var r=s.executeQuery("SELECT COUNT(*) FROM usuario")){r.next();if(r.getInt(1)!=0)throw new IllegalStateException("El administrador inicial ya existe.");}
            update(c,"INSERT INTO usuario(nombre_usuario,nombre,password_hash,rol) VALUES (?,?,?,'ADMIN')",username,name,hash);c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public User login(String username,String password)throws SQLException {
        session=null;
        try(var c=open();var s=prepare(c,"SELECT u.* FROM usuario u JOIN rol_definicion d ON d.codigo=u.rol WHERE u.nombre_usuario=? AND u.activo AND d.activo",validUsername(username));var r=s.executeQuery()){
            if(!r.next()||!Passwords.verify(password,r.getString("password_hash")))throw new SecurityException("Credenciales inválidas.");
            session=new User(r.getLong("id"),r.getString("nombre_usuario"),r.getString("nombre"),r.getString("rol"));return session;
        }
    }
    public void logout(){session=null;}
    public List<User> users()throws SQLException {requireModule(Module.USUARIOS);var list=new ArrayList<User>();try(var c=open();var s=c.createStatement();var r=s.executeQuery("SELECT * FROM usuario ORDER BY id")){while(r.next())list.add(new User(r.getLong("id"),r.getString("nombre_usuario"),r.getString("nombre")+(r.getBoolean("activo")?"":" [INACTIVO]"),r.getString("rol")));}return list;}
    public void saveUser(long id,String username,String name,String password,String role,boolean active)throws SQLException {
        var actor=requireModule(Module.USUARIOS);if(roles().stream().noneMatch(r->r.code().equals(role)&&r.active()))throw new IllegalArgumentException("Rol inválido.");
        if(id==actor.id()&&(!active||!role.equals(actor.role())))throw new IllegalArgumentException("No puedes quitar tus propios permisos administrativos.");
        username=validUsername(username);name=required(name,"Nombre");
        try(var c=open()){if(id==0)update(c,"INSERT INTO usuario(nombre_usuario,nombre,password_hash,rol,activo) VALUES (?,?,?,?,?)",username,name,Passwords.hash(password),role,active);
            else {update(c,"UPDATE usuario SET nombre_usuario=?,nombre=?,rol=?,activo=? WHERE id=?",username,name,role,active,id);if(!password.isEmpty())update(c,"UPDATE usuario SET password_hash=? WHERE id=?",Passwords.hash(password),id);}}
    }
    public List<Product> products()throws SQLException {requireAny(Module.INICIO,Module.PRODUCTOS,Module.MONITOREO,Module.FICHAS,Module.EXTRACCION,Module.REPORTES);try(var c=open()){return productDao.findAll(c);}}
    public Product product(long id)throws SQLException {return products().stream().filter(p->p.id()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Producto inexistente."));}
    public void saveProduct(Product p)throws SQLException {
        var actor=requireModule(Module.PRODUCTOS);if(!actor.admin()&&p.id()>0)throw new SecurityException("El rol solo permite registrar productos.");validateProduct(p);
        try(var c=open()){c.setAutoCommit(false);try{
            saveProductRow(c,p);c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    private static void validateProduct(Product p){required(p.code(),"Código");required(p.name(),"Nombre");required(p.brand(),"Marca");required(p.presentation(),"Presentación");required(p.capacity(),"Capacidad");required(p.category(),"Categoría");Economics.compare(p.cost(),p.price(),p.price());}
    private long saveProductRow(Connection c,Product p)throws SQLException {return productDao.save(c,p);}
    public long importReference(PlazaVeaImporter.Preview preview,Product reviewed,String condition)throws SQLException {
        var user=requireModule(Module.PRODUCTOS);if(!user.admin()&&reviewed.id()>0)throw new SecurityException("El rol solo permite registrar productos.");validateProduct(reviewed);PlazaVeaImporter.validateUrl(preview.url());required(condition,"Condición del precio de Plaza Vea");
        if(reviewed.price().compareTo(preview.price())!=0)throw new IllegalArgumentException("El precio propio debe coincidir con la captura revisada. Modifícalo después desde Productos si corresponde.");
        if(preview.captured().isBefore(OffsetDateTime.now().minusHours(24)))throw new IllegalArgumentException("La captura de Plaza Vea venció. Vuelve a obtener los datos.");
        try(var c=open()){c.setAutoCommit(false);try{
            long id=saveProductRow(c,reviewed),source=0;
            try(var s=c.createStatement();var r=s.executeQuery("SELECT id FROM fuente WHERE estrategia='VTEX' AND activo AND split_part(url,'/',3) IN ('www.plazavea.com.pe','plazavea.com.pe') ORDER BY id LIMIT 1")){if(r.next())source=r.getLong(1);}
            if(source==0)try(var s=prepare(c,"INSERT INTO fuente(nombre,url,selector_titulo,selector_precio,estrategia) VALUES ('Plaza Vea · precio propio','https://www.plazavea.com.pe','','','VTEX') RETURNING id");var r=s.executeQuery()){r.next();source=r.getLong(1);}
            update(c,"INSERT INTO producto_fuente(producto_id,fuente_id,url,condicion,programado,activo,es_referencia) VALUES (?,?,?,?,FALSE,TRUE,TRUE) ON CONFLICT(producto_id,fuente_id) DO UPDATE SET url=excluded.url,condicion=excluded.condicion,programado=FALSE,activo=TRUE,es_referencia=TRUE",id,source,preview.url(),condition);
            String attributes=new Gson().toJson(Map.of("marca",reviewed.brand(),"modelo",reviewed.model(),"presentacion",reviewed.presentation(),"capacidad",reviewed.capacity(),"sku",preview.sku(),"ean",preview.ean(),"advertencias",preview.warnings()));
            update(c,"INSERT INTO producto_referencia(producto_id,fuente_id,usuario_id,url,titulo,precio,capturado_en,evidencia,atributos) VALUES (?,?,?,?,?,?,?,?,?::jsonb)",id,source,user.id(),preview.url(),preview.title(),preview.price(),preview.captured(),preview.evidence(),attributes);
            c.commit();return id;
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public List<Source> sources()throws SQLException {requireAny(Module.INICIO,Module.PRODUCTOS,Module.MONITOREO,Module.FUENTES,Module.FICHAS,Module.EXTRACCION,Module.REPORTES);try(var c=open()){return sourceDao.findAll(c);}}
    public Source source(long id)throws SQLException {return sources().stream().filter(s->s.id()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Fuente inexistente."));}
    public Link configureSearch(long productId,String siteUrl,int interval,int validity,boolean scheduled)throws SQLException {
        return configureSearch(productId,siteUrl,interval,validity,scheduled,0);
    }
    public Link configureSearch(long productId,String siteUrl,int interval,int validity,boolean scheduled,long sourceId)throws SQLException {
        requireModule(Module.MONITOREO);String url=SearchService.canonical(siteUrl);var uri=java.net.URI.create(url);String host=uri.getHost();
        if(Set.of("www.plazavea.com.pe","plazavea.com.pe").contains(host))throw new IllegalArgumentException("Plaza Vea es el precio propio. Indica la web de otra fuente para buscar candidatos.");
        if(sourceId>0){var selected=source(sourceId);var sourceHost=java.net.URI.create(SearchService.canonical(selected.url())).getHost();if(!selected.active()||!sourceHost.replaceFirst("(?i)^www\\.","").equalsIgnoreCase(host.replaceFirst("(?i)^www\\.","")))throw new IllegalArgumentException("La URL debe pertenecer a la fuente activa seleccionada.");}
        if(interval<15||validity<1||validity>168)throw new IllegalArgumentException("Intervalo o vigencia inválidos.");
        try(var c=open()){c.setAutoCommit(false);try{
            try(var s=prepare(c,"SELECT 1 FROM producto p JOIN producto_referencia pr ON pr.producto_id=p.id WHERE p.id=? AND p.activo LIMIT 1",productId);var r=s.executeQuery()){if(!r.next())throw new IllegalArgumentException("Selecciona un producto activo importado de Plaza Vea.");}
            long source=sourceId;if(source==0)try(var s=prepare(c,"SELECT id FROM fuente WHERE lower(split_part(url,'/',3))=lower(?) AND activo ORDER BY CASE WHEN estrategia='AUTO' THEN 0 ELSE 1 END,id LIMIT 1",uri.getRawAuthority());var r=s.executeQuery()){if(r.next())source=r.getLong(1);}
            if(source==0)try(var s=prepare(c,"INSERT INTO fuente(nombre,url,selector_titulo,selector_precio,estrategia,intervalo,vigencia) VALUES (?,?, '', '', 'AUTO',?,?) RETURNING id",host,uri.getScheme()+"://"+uri.getRawAuthority(),interval,validity);var r=s.executeQuery()){r.next();source=r.getLong(1);}
            update(c,"INSERT INTO producto_fuente(producto_id,fuente_id,url,condicion,programado,activo,busqueda_automatica) VALUES (?,?,?,'Condiciones comerciales pendientes de verificar durante la homologación.',?,TRUE,TRUE) ON CONFLICT(producto_id,fuente_id) DO UPDATE SET url=excluded.url,condicion=excluded.condicion,programado=excluded.programado,activo=TRUE,busqueda_automatica=TRUE",productId,source,url,scheduled);
            c.commit();final long selectedSource=source;return links().stream().filter(l->l.productId()==productId&&l.sourceId()==selectedSource).findFirst().orElseThrow();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    /** Atomically replaces the enabled external sources for one own product. */
    public void selectProductSources(long productId,Set<Long> sourceIds,boolean scheduled)throws SQLException {
        int minutes=monitoringSettings().getOrDefault(productId,new MonitoringSettings(60,false)).minutes();selectProductSources(productId,sourceIds,scheduled,minutes);
    }
    public void selectProductSources(long productId,Set<Long> sourceIds,boolean scheduled,int minutes)throws SQLException {
        requireModule(Module.MONITOREO);if(minutes<1||minutes>10080)throw new IllegalArgumentException("Frecuencia inválida.");var selected=Set.copyOf(sourceIds);
        try(var c=open()){c.setAutoCommit(false);try{
            try(var q=prepare(c,"SELECT 1 FROM producto p JOIN producto_referencia pr ON pr.producto_id=p.id WHERE p.id=? AND p.activo LIMIT 1",productId);var r=q.executeQuery()){if(!r.next())throw new IllegalArgumentException("Selecciona un producto activo importado de Plaza Vea.");}
            var available=new HashMap<Long,String>();
            try(var q=c.createStatement();var r=q.executeQuery("SELECT id,url,estrategia FROM fuente WHERE activo")){while(r.next()){
                String url=r.getString("url");if(r.getString("estrategia").equals("DEMO"))continue;
                String host=java.net.URI.create(SearchService.canonical(url)).getHost().replaceFirst("(?i)^www\\.","");
                if(!host.equalsIgnoreCase("plazavea.com.pe"))available.put(r.getLong("id"),url);
            }}
            if(!available.keySet().containsAll(selected))throw new IllegalArgumentException("Una fuente no existe, está inactiva o corresponde al precio propio.");
            update(c,"UPDATE producto_fuente SET activo=FALSE,programado=FALSE WHERE producto_id=? AND NOT es_referencia",productId);
            update(c,"INSERT INTO producto_monitoreo(producto_id,intervalo_min,programado) VALUES (?,?,?) ON CONFLICT(producto_id) DO UPDATE SET intervalo_min=excluded.intervalo_min,programado=excluded.programado",productId,minutes,scheduled);
            for(long id:selected)update(c,"INSERT INTO producto_fuente(producto_id,fuente_id,url,condicion,programado,activo,busqueda_automatica) VALUES (?,?,?,'Condiciones pendientes de revisar durante la homologación.',?,TRUE,TRUE) ON CONFLICT(producto_id,fuente_id) DO UPDATE SET activo=TRUE,programado=excluded.programado,proxima_ejecucion=CURRENT_TIMESTAMP",productId,id,available.get(id),scheduled);
            c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public void configureMonitoring(long productId,Source config,String productUrl,String condition,boolean scheduled)throws SQLException {
        requireModule(Module.MONITOREO);var own=product(productId);if(!own.active())throw new IllegalArgumentException("El producto está inactivo.");
        Extractor.validateUrl(productUrl,false);var uri=java.net.URI.create(productUrl);String host=uri.getHost().toLowerCase(Locale.ROOT);
        if(Set.of("www.plazavea.com.pe","plazavea.com.pe").contains(host))throw new IllegalArgumentException("Plaza Vea es el precio propio. Indica una página diferente para comparar.");
        required(condition,"Condición del precio externo");required(config.name(),"Nombre de fuente");
        if(!Set.of("CSS","VTEX","JSON_LD").contains(config.strategy())||config.interval()<15||config.validity()<1||config.validity()>168)throw new IllegalArgumentException("Configuración inválida.");
        if(config.strategy().equals("CSS")){required(config.titleSelector(),"Selector de título");required(config.priceSelector(),"Selector de precio");org.jsoup.Jsoup.parse("").select(config.titleSelector());org.jsoup.Jsoup.parse("").select(config.priceSelector());}
        try(var c=open()){c.setAutoCommit(false);try{
            try(var s=prepare(c,"SELECT 1 FROM producto_referencia WHERE producto_id=? LIMIT 1",productId);var r=s.executeQuery()){if(!r.next())throw new IllegalArgumentException("Primero carga y guarda el producto desde su URL de Plaza Vea.");}
            long source=0;try(var s=prepare(c,"SELECT id FROM fuente WHERE split_part(url,'/',3)=? AND estrategia=? AND activo AND selector_titulo=? AND selector_precio=? AND atributo_titulo=? AND atributo_precio=? ORDER BY id LIMIT 1",uri.getRawAuthority(),config.strategy(),config.titleSelector(),config.priceSelector(),config.titleAttribute(),config.priceAttribute());var r=s.executeQuery()){if(r.next())source=r.getLong(1);}
            if(source==0)try(var s=prepare(c,"INSERT INTO fuente(nombre,url,selector_titulo,selector_precio,atributo_titulo,atributo_precio,estrategia,intervalo,vigencia) VALUES (?,?,?,?,?,?,?,?,?) RETURNING id",config.name(),uri.getScheme()+"://"+uri.getRawAuthority(),config.titleSelector(),config.priceSelector(),config.titleAttribute(),config.priceAttribute(),config.strategy(),config.interval(),config.validity());var r=s.executeQuery()){r.next();source=r.getLong(1);}
            update(c,"INSERT INTO producto_fuente(producto_id,fuente_id,url,condicion,programado,activo) VALUES (?,?,?,?,?,TRUE) ON CONFLICT(producto_id,fuente_id) DO UPDATE SET url=excluded.url,condicion=excluded.condicion,programado=excluded.programado,activo=TRUE",productId,source,productUrl,condition,scheduled);
            c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public void saveSource(Source s)throws SQLException {
        requireModule(Module.FUENTES);required(s.name(),"Nombre de fuente");Extractor.validateUrl(s.url(),s.strategy().equals("DEMO"));
        if(!Set.of("CSS","VTEX","JSON_LD","DEMO","AUTO").contains(s.strategy())||s.interval()<15||s.validity()<1||s.validity()>168)throw new IllegalArgumentException("Estrategia, intervalo o vigencia inválidos.");
        if(s.strategy().equals("CSS")){required(s.titleSelector(),"Selector de título");required(s.priceSelector(),"Selector de precio");org.jsoup.Jsoup.parse("").select(s.titleSelector());org.jsoup.Jsoup.parse("").select(s.priceSelector());}
        try(var c=open()){sourceDao.save(c,s);}
    }
    public List<Link> links()throws SQLException {
        requireAny(Module.INICIO,Module.PRODUCTOS,Module.MONITOREO,Module.FICHAS,Module.EXTRACCION);var list=new ArrayList<Link>();try(var c=open();var s=c.createStatement();var r=s.executeQuery("SELECT pf.*,p.nombre producto,f.nombre fuente FROM producto_fuente pf JOIN producto p ON p.id=pf.producto_id JOIN fuente f ON f.id=pf.fuente_id ORDER BY pf.id")){
            while(r.next())list.add(new Link(r.getLong("id"),r.getLong("producto_id"),r.getLong("fuente_id"),r.getString("producto"),r.getString("fuente"),r.getString("url"),r.getString("condicion"),r.getBoolean("programado"),r.getBoolean("activo"),r.getBoolean("es_referencia"),r.getBoolean("busqueda_automatica")));
        }return list;
    }
    public void saveLink(long id,long product,long source,String url,String condition,boolean scheduled,boolean active)throws SQLException {
        requireModule(Module.FICHAS);var f=source(source);Extractor.validateUrl(url,f.strategy().equals("DEMO"));required(condition,"Condición de oferta");
        if(id>0&&links().stream().anyMatch(l->l.id()==id&&l.reference()))throw new IllegalArgumentException("Actualiza la ficha de precio propio desde Producto Plaza Vea.");
        if(!f.strategy().equals("DEMO")&&Set.of("www.plazavea.com.pe","plazavea.com.pe").contains(java.net.URI.create(url).getHost().toLowerCase(Locale.ROOT))){
            try(var c=open();var s=prepare(c,"SELECT 1 FROM producto_referencia WHERE producto_id=? LIMIT 1",product);var r=s.executeQuery()){if(r.next())throw new IllegalArgumentException("Plaza Vea ya es el precio propio. Configura una fuente distinta para comparar.");}
        }
        if(!f.strategy().equals("DEMO")&&!java.net.URI.create(url).getHost().equalsIgnoreCase(java.net.URI.create(f.url()).getHost()))throw new IllegalArgumentException("La ficha debe pertenecer al dominio configurado en la fuente.");
        try(var c=open()){if(id==0)update(c,"INSERT INTO producto_fuente(producto_id,fuente_id,url,condicion,programado,activo) VALUES (?,?,?,?,?,?)",product,source,url,condition,scheduled,active);
            else update(c,"UPDATE producto_fuente SET producto_id=?,fuente_id=?,url=?,condicion=?,programado=?,activo=? WHERE id=?",product,source,url,condition,scheduled,active,id);}
    }
    public List<Link> dueLinks()throws SQLException {
        requireModule(Module.EXTRACCION);var ids=new HashSet<Long>();try(var c=open();var s=c.createStatement();var r=s.executeQuery("SELECT pf.id FROM producto_fuente pf JOIN producto p ON p.id=pf.producto_id JOIN fuente f ON f.id=pf.fuente_id WHERE pf.programado AND NOT pf.es_referencia AND pf.activo AND p.activo AND f.activo AND pf.proxima_ejecucion<=CURRENT_TIMESTAMP AND EXISTS(SELECT 1 FROM producto_homologado ph WHERE ph.producto_id=pf.producto_id AND ph.fuente_id=pf.fuente_id AND ph.estado='ACTIVO')")){while(r.next())ids.add(r.getLong(1));}
        return links().stream().filter(l->ids.contains(l.id())).toList();
    }
    public long start(Link link)throws SQLException {
        if(link.reference())throw new IllegalArgumentException("La ficha de Plaza Vea corresponde al precio propio. Selecciona una fuente para comparar.");
        var user=requireModule(Module.EXTRACCION);try(var c=open()){c.setAutoCommit(false);try{
            try(var s=prepare(c,"SELECT p.activo AND f.activo AND pf.activo AND NOT pf.es_referencia habilitado,COALESCE(pm.intervalo_min,f.intervalo) intervalo FROM producto_fuente pf JOIN producto p ON p.id=pf.producto_id JOIN fuente f ON f.id=pf.fuente_id LEFT JOIN producto_monitoreo pm ON pm.producto_id=p.id WHERE pf.id=? FOR UPDATE OF pf",link.id());var r=s.executeQuery()){
                if(!r.next()||!r.getBoolean(1))throw new IllegalArgumentException("Producto, fuente o vínculo inactivo.");
                update(c,"UPDATE producto_fuente SET proxima_ejecucion=CURRENT_TIMESTAMP + (? * interval '1 minute') WHERE id=?",r.getInt(2),link.id());
            }
            long id;try(var s=prepare(c,"INSERT INTO ejecucion(producto_id,fuente_id,usuario_id,vinculo_id,url) VALUES (?,?,?,?,?) RETURNING id",link.productId(),link.sourceId(),user.id(),link.id(),link.url());var r=s.executeQuery()){r.next();id=r.getLong(1);}c.commit();return id;
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public void success(long run,Extractor.Quote quote,String condition)throws SQLException {
        complete(run,List.of(quote),condition,null);
    }
    public void searchSuccess(long run,SearchService.Result result,String condition)throws SQLException {
        complete(run,result.quotes(),condition,new Gson().toJson(result));
    }
    private void complete(long run,List<Extractor.Quote> quotes,String condition,String summary)throws SQLException {
        complete(run,quotes,condition,summary,null);
    }
    public void completeHomologated(long run,Extractor.Quote quote,String condition,long approved)throws SQLException {complete(run,List.of(quote),condition,null,approved);}
    private void complete(long run,List<Extractor.Quote> quotes,String condition,String summary,Long approved)throws SQLException {
        var actor=requireModule(Module.EXTRACCION);try(var c=open()){c.setAutoCommit(false);try{
          if(approved!=null)try(var q=prepare(c,"SELECT p.id FROM producto p JOIN ejecucion e ON e.producto_id=p.id WHERE e.id=? FOR UPDATE OF p",run);var r=q.executeQuery()){if(!r.next())throw new IllegalArgumentException("Ejecución inexistente.");}
          for(var quote:quotes){
            long id;try(var s=prepare(c,"INSERT INTO resultado(ejecucion_id,titulo,precio,url,condicion,evidencia) VALUES (?,?,?,?,?,?) RETURNING id",run,quote.title(),quote.price(),quote.url(),condition,quote.evidence());var r=s.executeQuery()){r.next();id=r.getLong(1);}
            update(c,"INSERT INTO historico_precio(resultado_id,producto_id,fuente_id,precio,fecha,url) SELECT r.id,e.producto_id,e.fuente_id,r.precio,r.fecha,r.url FROM resultado r JOIN ejecucion e ON e.id=r.ejecucion_id WHERE r.id=?",id);
            if(approved!=null){
              boolean matches;try(var q=prepare(c,"SELECT ph.titulo,ph.atributos_propios,p.atributos,ph.estado,ph.url FROM producto_homologado ph JOIN producto p ON p.id=ph.producto_id JOIN ejecucion e ON e.producto_id=ph.producto_id AND e.fuente_id=ph.fuente_id WHERE ph.id=? AND e.id=? FOR UPDATE OF ph",approved,run);var r=q.executeQuery()){
                if(!r.next())throw new IllegalArgumentException("Homologación inexistente.");matches=r.getString("estado").equals("ACTIVO")&&sameTitle(r.getString("titulo"),quote.title())&&r.getString("atributos_propios").equals(r.getString("atributos"))&&r.getString("url").equals(quote.url());
              }
              if(matches){validateRow(c,id,"CONFIRMADO","Consulta automática de producto homologado",actor);trackAndCompare(c,id,actor,false);}
              else update(c,"UPDATE producto_homologado SET estado='REVISAR',motivo='Cambió la identidad del producto o requiere nueva revisión.' WHERE id=?",approved);
            }
          }
            update(c,"UPDATE ejecucion SET estado=?,fin=CURRENT_TIMESTAMP,resumen_busqueda=?::jsonb WHERE id=?",quotes.isEmpty()?"SIN_RESULTADOS":"OK",summary,run);c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public void fail(long run,String error)throws SQLException {requireModule(Module.EXTRACCION);try(var c=open()){update(c,"UPDATE ejecucion SET estado='ERROR',fin=CURRENT_TIMESTAMP,error=? WHERE id=?",error,run);}}
    public List<Candidate> candidates(long product)throws SQLException {
        return candidatesForRun(product,0);
    }
    public List<Candidate> candidatesForRun(long product,long run)throws SQLException {
        requireAny(Module.EXTRACCION,Module.REPORTES);var list=new ArrayList<Candidate>();try(var c=open();var s=prepare(c,"SELECT r.*,e.fuente_id source_id,f.nombre source_name,c.id compared_id,c.propio compared_own,c.costo compared_cost,c.externo compared_external,c.alerta compared_alert FROM resultado r JOIN ejecucion e ON e.id=r.ejecucion_id JOIN fuente f ON f.id=e.fuente_id LEFT JOIN comparacion c ON c.resultado_id=r.id WHERE e.producto_id=? AND (?=0 OR e.id=?) ORDER BY r.id DESC",product,run,run);var r=s.executeQuery()){
            while(r.next())list.add(new Candidate(r.getLong("id"),r.getString("titulo"),r.getBigDecimal("precio"),r.getString("url"),r.getString("estado"),r.getString("condicion"),r.getObject("fecha",OffsetDateTime.class),r.getString("evidencia"),r.getObject("compared_id")==null?null:new ComparisonSnapshot(r.getLong("compared_id"),r.getBigDecimal("compared_own"),r.getBigDecimal("compared_cost"),r.getBigDecimal("compared_external"),r.getString("compared_alert")),r.getString("source_name"),r.getLong("source_id")));
        }return list;
    }
    public void validate(long id,boolean confirmed,String note)throws SQLException {
        var user=requireModule(Module.EXTRACCION);required(note,"Evidencia de revisión");String state=confirmed?"CONFIRMADO":"RECHAZADO";
        try(var c=open()){c.setAutoCommit(false);try{
            validateRow(c,id,state,note,user);c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    private static void validateRow(Connection c,long id,String state,String note,User user)throws SQLException {
        if(update(c,"UPDATE resultado SET estado=?,responsable=?,observacion=?,validado_en=CURRENT_TIMESTAMP WHERE id=? AND estado='PENDIENTE'",state,user.username(),note,id)!=1)throw new IllegalStateException("El candidato ya fue revisado.");
        update(c,"INSERT INTO homologacion(resultado_id,usuario_id,estado,observacion) VALUES (?,?,?,?)",id,user.id(),state,note);
    }
    public Economics.Result confirmAndCompare(long id,String note)throws SQLException {
        var user=requireModule(Module.EXTRACCION);try(var c=open()){c.setAutoCommit(false);try{
            String state;try(var s=prepare(c,"SELECT estado FROM resultado WHERE id=? FOR UPDATE",id);var r=s.executeQuery()){if(!r.next())throw new IllegalArgumentException("Candidato inexistente.");state=r.getString(1);}
            if(state.equals("RECHAZADO"))throw new IllegalArgumentException("Un candidato rechazado no puede compararse.");
            try(var s=prepare(c,"SELECT costo,propio,externo FROM comparacion WHERE resultado_id=?",id);var r=s.executeQuery()){if(r.next()){var result=Economics.compare(r.getBigDecimal("costo"),r.getBigDecimal("propio"),r.getBigDecimal("externo"));c.commit();return result;}}
            if(state.equals("PENDIENTE"))validateRow(c,id,"CONFIRMADO",required(note,"Evidencia de equivalencia"),user);
            var result=trackAndCompare(c,id,user,true);c.commit();return result;
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public Economics.Result compare(long id)throws SQLException {
        var user=requireModule(Module.EXTRACCION);try(var c=open()){c.setAutoCommit(false);try{
            var result=compareRow(c,id,user);c.commit();return result;
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    private static Economics.Result compareRow(Connection c,long id,User user)throws SQLException {return compareRow(c,id,user,null,null);}
    private static Economics.Result compareRow(Connection c,long id,User user,String trackingType,BigDecimal previous)throws SQLException {
            Economics.Result result;
            try(var s=prepare(c,"SELECT p.*,r.precio externo,r.fecha,f.vigencia FROM resultado r JOIN homologacion h ON h.resultado_id=r.id AND h.estado='CONFIRMADO' JOIN ejecucion e ON e.id=r.ejecucion_id JOIN producto p ON p.id=e.producto_id JOIN fuente f ON f.id=e.fuente_id LEFT JOIN producto_fuente pf ON pf.id=e.vinculo_id WHERE r.id=? AND r.estado='CONFIRMADO' AND p.activo AND f.activo AND NOT COALESCE(pf.es_referencia,FALSE) FOR UPDATE OF r,p",id);var r=s.executeQuery()){
                if(!r.next())throw new IllegalArgumentException("Se requiere homologación confirmada y catálogo activo.");
                if(r.getObject("fecha",OffsetDateTime.class).plusHours(r.getInt("vigencia")).isBefore(OffsetDateTime.now()))throw new IllegalArgumentException("Precio vencido. Ejecuta una nueva consulta.");
                var cost=r.getBigDecimal("costo");var own=r.getBigDecimal("precio");var external=r.getBigDecimal("externo");result=Economics.compare(cost,own,external);
                String type=trackingType==null?(result.loss()?"PERDIDA":result.lower()?"PRECIO_INFERIOR":"SIN_ALERTA"):trackingType;long comparison;
                try(var save=prepare(c,"INSERT INTO comparacion(resultado_id,costo,propio,externo,diferencia,utilidad_actual,utilidad_simulada,margen_actual,margen_simulado,alerta,usuario_id,producto_snapshot,atributos_snapshot) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(resultado_id) DO NOTHING RETURNING id",id,cost,own,external,result.difference(),result.currentProfit(),result.simulatedProfit(),result.currentMargin(),result.simulatedMargin(),type,user.id(),r.getString("nombre"),r.getString("atributos"));var saved=save.executeQuery()){
                    if(!saved.next())throw new IllegalStateException("El resultado ya tiene comparación histórica.");comparison=saved.getLong(1);
                }
                if(trackingType!=null)update(c,"UPDATE comparacion SET precio_anterior=?,variacion=? WHERE id=?",previous,previous==null?null:external.subtract(previous),comparison);
                if(!type.equals("SIN_ALERTA"))update(c,"INSERT INTO alerta(comparacion_id,tipo) VALUES (?,?)",comparison,type);
            }return result;
    }
    private static String identity(String value){return java.text.Normalizer.normalize(value,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();}
    private static boolean sameTitle(String a,String b){return identity(a).equals(identity(b));}
    public List<Homologated> homologated()throws SQLException {return homologated(0,0);}
    public List<Homologated> homologated(long product,long source)throws SQLException {
        requireAny(Module.FICHAS,Module.EXTRACCION);var list=new ArrayList<Homologated>();try(var c=open();var q=prepare(c,"SELECT ph.*,p.nombre producto,f.nombre fuente FROM producto_homologado ph JOIN producto p ON p.id=ph.producto_id JOIN fuente f ON f.id=ph.fuente_id WHERE (?=0 OR ph.producto_id=?) AND (?=0 OR ph.fuente_id=?) ORDER BY p.nombre,f.nombre,ph.id",product,product,source,source);var r=q.executeQuery()){
            while(r.next())list.add(new Homologated(r.getLong("id"),r.getLong("producto_id"),r.getLong("fuente_id"),r.getString("producto"),r.getString("fuente"),r.getString("url"),r.getString("titulo"),r.getBigDecimal("ultimo_precio"),r.getString("estado"),r.getString("motivo"),r.getObject("homologado_en",OffsetDateTime.class),r.getObject("verificado_en",OffsetDateTime.class)));}return List.copyOf(list);
    }
    private static Economics.Result trackAndCompare(Connection c,long id,User actor,boolean manual)throws SQLException {
        long product,source;String url,title,attributes,condition;BigDecimal price;OffsetDateTime captured;
        try(var q=prepare(c,"SELECT r.*,e.producto_id,e.fuente_id,p.atributos FROM resultado r JOIN ejecucion e ON e.id=r.ejecucion_id JOIN producto p ON p.id=e.producto_id WHERE r.id=?",id);var r=q.executeQuery()){
            if(!r.next())throw new IllegalArgumentException("Candidato inexistente.");product=r.getLong("producto_id");source=r.getLong("fuente_id");url=r.getString("url");title=r.getString("titulo");attributes=r.getString("atributos");condition=r.getString("condicion");price=r.getBigDecimal("precio");captured=r.getObject("fecha",OffsetDateTime.class);
        }
        // Serialize baseline updates per product, including concurrent first approvals.
        try(var q=prepare(c,"SELECT id FROM producto WHERE id=? FOR UPDATE",product);var r=q.executeQuery()){r.next();}
        BigDecimal previous=null;
        try(var q=prepare(c,"SELECT ultimo_precio,verificado_en,estado,titulo,atributos_propios FROM producto_homologado WHERE producto_id=? AND fuente_id=? AND url=? FOR UPDATE",product,source,url);var r=q.executeQuery()){
            if(r.next()){if(captured.isBefore(r.getObject("verificado_en",OffsetDateTime.class)))throw new IllegalArgumentException("La captura es anterior a la última consulta homologada.");if(r.getString("estado").equals("ACTIVO")&&sameTitle(r.getString("titulo"),title)&&r.getString("atributos_propios").equals(attributes))previous=r.getBigDecimal("ultimo_precio");}
        }
        String type=previous==null||price.compareTo(previous)==0?"SIN_ALERTA":price.compareTo(previous)>0?"SUBIDA_PRECIO":"BAJADA_PRECIO";
        var result=compareRow(c,id,actor,type,previous);
        update(c,"INSERT INTO producto_homologado(producto_id,fuente_id,url,titulo,atributos_propios,condicion,usuario_id,ultimo_resultado_id,ultimo_precio,verificado_en) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(producto_id,fuente_id,url) DO UPDATE SET titulo=excluded.titulo,atributos_propios=excluded.atributos_propios,condicion=excluded.condicion,usuario_id=CASE WHEN producto_homologado.estado='REVISAR' THEN excluded.usuario_id ELSE producto_homologado.usuario_id END,homologado_en=CASE WHEN producto_homologado.estado='REVISAR' THEN CURRENT_TIMESTAMP ELSE producto_homologado.homologado_en END,ultimo_resultado_id=excluded.ultimo_resultado_id,ultimo_precio=excluded.ultimo_precio,verificado_en=excluded.verificado_en,estado='ACTIVO',motivo=''",product,source,url,title,attributes,condition,actor.id(),id,price,captured);
        if(manual){
            update(c,"INSERT INTO producto_monitoreo(producto_id,intervalo_min,programado) VALUES (?,60,TRUE) ON CONFLICT(producto_id) DO UPDATE SET programado=TRUE",product);
            update(c,"UPDATE producto_fuente SET programado=TRUE WHERE producto_id=? AND fuente_id=? AND activo AND NOT es_referencia",product,source);
        }
        return result;
    }
    public List<AlertItem> alerts()throws SQLException {
        requireAny(Module.INICIO,Module.ALERTAS,Module.REPORTES);var list=new ArrayList<AlertItem>();try(var c=open();var s=c.createStatement();var r=s.executeQuery("SELECT a.*,c.producto_snapshot FROM alerta a JOIN comparacion c ON c.id=a.comparacion_id ORDER BY a.id DESC")){while(r.next())list.add(new AlertItem(r.getLong("id"),r.getString("producto_snapshot"),r.getString("tipo"),r.getString("estado"),r.getString("observacion")));}return list;
    }
    public AlertDetail alertDetail(long id)throws SQLException {
        requireModule(Module.ALERTAS);try(var c=open();var q=prepare(c,"SELECT a.*,c.producto_snapshot,c.propio,c.externo,c.diferencia,c.precio_anterior,c.variacion,c.fecha,r.url,f.nombre fuente,p.id producto_id,p.costo costo_actual,p.precio precio_actual,d.accion,d.precio_anterior AS precio_anterior_decision,d.precio_nuevo,d.costo costo_decision,d.utilidad,d.margen,d.observacion nota_decision,d.fecha fecha_decision FROM alerta a JOIN comparacion c ON c.id=a.comparacion_id JOIN resultado r ON r.id=c.resultado_id JOIN ejecucion e ON e.id=r.ejecucion_id JOIN fuente f ON f.id=e.fuente_id JOIN producto p ON p.id=e.producto_id LEFT JOIN alerta_decision_precio d ON d.alerta_id=a.id WHERE a.id=?",id);var r=q.executeQuery()){
            if(!r.next())throw new IllegalArgumentException("Alerta inexistente.");var decision=r.getString("accion")==null?null:new PriceRecord(r.getString("accion"),r.getBigDecimal("precio_anterior_decision"),r.getBigDecimal("precio_nuevo"),r.getBigDecimal("costo_decision"),r.getBigDecimal("utilidad"),r.getBigDecimal("margen"),r.getString("nota_decision"),r.getObject("fecha_decision",OffsetDateTime.class));
            return new AlertDetail(id,r.getString("producto_snapshot"),r.getString("fuente"),r.getString("tipo"),r.getString("estado"),r.getBigDecimal("propio"),r.getBigDecimal("externo"),r.getBigDecimal("diferencia"),r.getString("url"),r.getObject("fecha",OffsetDateTime.class),r.getLong("producto_id"),r.getBigDecimal("costo_actual"),r.getBigDecimal("precio_actual"),decision,r.getBigDecimal("precio_anterior"),r.getBigDecimal("variacion"));
        }
    }
    /** Saves one decision, the local sale price and alert attention as one transaction. */
    public PriceRecord decidePrice(long alertId,PriceDecision.Action action,BigDecimal proposed,BigDecimal expectedPrice,BigDecimal expectedCost,String note)throws SQLException {
        var actor=requireModule(Module.ALERTAS);try(var c=open()){c.setAutoCommit(false);try{
            long product;BigDecimal cost,current,competitor;
            try(var q=prepare(c,"SELECT p.id,p.costo,p.precio,c.externo FROM alerta a JOIN comparacion c ON c.id=a.comparacion_id JOIN resultado r ON r.id=c.resultado_id JOIN ejecucion e ON e.id=r.ejecucion_id JOIN producto p ON p.id=e.producto_id WHERE a.id=? FOR UPDATE OF a,p",alertId);var r=q.executeQuery()){if(!r.next())throw new IllegalArgumentException("Alerta inexistente.");product=r.getLong("id");cost=r.getBigDecimal("costo");current=r.getBigDecimal("precio");competitor=r.getBigDecimal("externo");}
            try(var q=prepare(c,"SELECT 1 FROM alerta_decision_precio WHERE alerta_id=?",alertId);var r=q.executeQuery()){if(r.next())throw new IllegalStateException("La alerta ya tiene una decisión de precio.");}
            if(expectedPrice==null||expectedCost==null||current.compareTo(expectedPrice)!=0||cost.compareTo(expectedCost)!=0)throw new IllegalStateException("El precio o costo cambió. Actualiza la alerta.");
            var simulation=PriceDecision.simulate(action,cost,current,competitor,proposed);String observation=note==null?"":note.trim();
            if(action!=PriceDecision.Action.KEEP)update(c,"UPDATE producto SET precio=? WHERE id=?",simulation.price(),product);
            update(c,"INSERT INTO alerta_decision_precio(alerta_id,producto_id,usuario_id,accion,precio_anterior,precio_nuevo,costo,utilidad,margen,observacion) VALUES (?,?,?,?,?,?,?,?,?,?)",alertId,product,actor.id(),action.name(),current,simulation.price(),cost,simulation.profit(),simulation.margin(),observation);
            String attention=action+" · Precio S/ "+simulation.price()+" · Utilidad S/ "+simulation.profit()+(observation.isBlank()?"":" · "+observation);
            update(c,"UPDATE alerta SET estado='ATENDIDA',observacion=?,responsable_id=?,atendida_en=CURRENT_TIMESTAMP WHERE id=?",attention,actor.id(),alertId);
            update(c,"INSERT INTO alerta_atencion(alerta_id,usuario_id,estado,observacion) VALUES (?,?,'ATENDIDA',?)",alertId,actor.id(),attention);c.commit();return new PriceRecord(action.name(),current,simulation.price(),cost,simulation.profit(),simulation.margin(),observation,OffsetDateTime.now());
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public void attend(long id,String state,String note)throws SQLException {
        var u=requireModule(Module.ALERTAS);if(!Set.of("EN_REVISION","ATENDIDA","DESCARTADA").contains(state))throw new IllegalArgumentException("Estado inválido.");required(note,"Observación");
        try(var c=open()){c.setAutoCommit(false);try{
            if(update(c,"UPDATE alerta SET estado=?,observacion=?,responsable_id=?,atendida_en=CURRENT_TIMESTAMP WHERE id=?",state,note,u.id(),id)!=1)throw new IllegalArgumentException("Alerta inexistente.");
            update(c,"INSERT INTO alerta_atencion(alerta_id,usuario_id,estado,observacion) VALUES (?,?,?,?)",id,u.id(),state,note);c.commit();
        }catch(SQLException|RuntimeException e){c.rollback();throw e;}}
    }
    public ReportData report(ReportType type,ReportFilter filter)throws SQLException {
        requireModule(Module.REPORTES);if(filter.from()!=null&&filter.to()!=null&&filter.from().isAfter(filter.to()))throw new IllegalArgumentException("Rango de fechas inválido.");
        var rows=new ArrayList<List<String>>();var columns=new ArrayList<String>();
        var lima=ZoneId.of("America/Lima");
        OffsetDateTime from=filter.from()==null?OffsetDateTime.parse("1970-01-01T00:00:00Z"):filter.from().atStartOfDay(lima).toOffsetDateTime();
        OffsetDateTime to=filter.to()==null?OffsetDateTime.parse("9999-01-01T00:00:00Z"):filter.to().plusDays(1).atStartOfDay(lima).toOffsetDateTime();
        try(var c=open();var s=prepare(c,type.sql()+" WHERE (?=0 OR e.producto_id=?) AND (?=0 OR e.fuente_id=?) AND "+type.dateColumn()+">=? AND "+type.dateColumn()+"<? ORDER BY "+type.dateColumn()+" DESC",filter.product(),filter.product(),filter.source(),filter.source(),from,to);var r=s.executeQuery()){
            var meta=r.getMetaData();for(int i=1;i<=meta.getColumnCount();i++)columns.add(meta.getColumnLabel(i));
            while(r.next()){var row=new ArrayList<String>();for(int i=1;i<=columns.size();i++){
                Object value=r.getObject(i);
                if(value!=null&&meta.getColumnTypeName(i).equals("timestamptz"))value=r.getObject(i,OffsetDateTime.class).atZoneSameInstant(lima).format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
                row.add(Objects.toString(value,""));
            }rows.add(row);}
        }return new ReportData(type.toString(),List.copyOf(columns),List.copyOf(rows));
    }
    public void recordExport(ReportType type,ReportFilter filter,String path)throws SQLException {var u=requireModule(Module.REPORTES);try(var c=open()){update(c,"INSERT INTO reporte(usuario_id,tipo,parametros,archivo) VALUES (?,?,?::jsonb,?)",u.id(),type.name(),new Gson().toJson(Map.of("producto",filter.product(),"fuente",filter.source(),"desde",Objects.toString(filter.from(),""),"hasta",Objects.toString(filter.to(),""))),path);}}
    public static String required(String value,String field){if(value==null||value.isBlank())throw new IllegalArgumentException("Completa: "+field);return value.trim();}
    private static String validUsername(String username){username=required(username,"Usuario").toLowerCase(Locale.ROOT);if(!username.matches("[a-z0-9][a-z0-9._-]{2,39}"))throw new IllegalArgumentException("Usuario inválido: utiliza de 3 a 40 letras, números, puntos, guiones o guiones bajos; empieza con letra o número.");return username;}
    private static PreparedStatement prepare(Connection c,String sql,Object... values)throws SQLException {var s=c.prepareStatement(sql);s.setQueryTimeout(12);for(int i=0;i<values.length;i++)s.setObject(i+1,values[i]);return s;}
    private static int update(Connection c,String sql,Object... values)throws SQLException {try(var s=prepare(c,sql,values)){return s.executeUpdate();}}
}
