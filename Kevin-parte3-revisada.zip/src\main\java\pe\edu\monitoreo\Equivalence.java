package pe.edu.monitoreo;

import java.text.Normalizer;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Pattern;

/** Evidence for the BPMN confidence gateway; never authorizes a comparison by itself. */
public final class Equivalence {
    public record Assessment(int confidence,List<String> reasons){}
    private Equivalence(){}
    public static Assessment assess(Store.Product own,String candidate){
        var reasons=new ArrayList<String>();int checks=0,matched=0;String title=normalize(candidate);
        for(var field:List.of(Map.entry("Marca",own.brand()),Map.entry("Modelo/variedad",own.model()),Map.entry("Presentación",own.presentation()))) {
            if(field.getValue().isBlank())continue;checks++;boolean found=Arrays.stream(normalize(field.getValue()).split("\\s+")).allMatch(token->(" "+title+" ").contains(" "+token+" "));
            if(found)matched++;reasons.add(field.getKey()+": "+(found?"coincidencia en título":"requiere revisión"));
        }
        checks++;var sizes=quantities(own.capacity());var other=quantities(candidate);boolean size=!sizes.isEmpty()&&other.containsAll(sizes);if(size)matched++;
        reasons.add("Capacidad: "+(size?"coincidencia numérica y de unidad":"no se acredita la misma presentación"));
        reasons.add("Verifica cantidad por paquete y condiciones comerciales. La puntuación no confirma la homologación.");
        return new Assessment(checks==0?0:100*matched/checks,List.copyOf(reasons));
    }
    private static Set<String> quantities(String value){
        value=value.replaceAll("(?i)\\bsixpack\\b","6 un").replaceAll("(?i)\\btripack\\b","3 un").replaceAll("(?i)\\bpack\\s+(?:de\\s+)?(\\d+)\\b","$1 un");
        var out=new HashSet<String>();var matcher=Pattern.compile("(?i)(\\d+(?:[.,]\\d+)?)\\s*(ml|kg|g|litros?|l|un(?:d)?)\\b").matcher(value);
        while(matcher.find()){var amount=new BigDecimal(matcher.group(1).replace(',','.'));String unit=matcher.group(2).toLowerCase(Locale.ROOT);if(unit.equals("l")||unit.startsWith("litro")){amount=amount.multiply(new BigDecimal("1000"));unit="ml";}if(unit.equals("kg")){amount=amount.multiply(new BigDecimal("1000"));unit="g";}out.add(amount.stripTrailingZeros().toPlainString()+unit);}return out;
    }
    private static String normalize(String s){return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();}
}
