package pe.edu.monitoreo;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.io.TempDir;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.nio.file.*;
import java.time.*;
import static org.junit.jupiter.api.Assertions.*;

@EnabledIfEnvironmentVariable(named="INTEGRATION_DB_URL",matches=".+")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class StoreIntegrationTest {
    Store store;String url,user,password,schema;Store.Link link;
    @TempDir Path dir;
    @BeforeAll void setup()throws Exception {
        url=System.getenv("INTEGRATION_DB_URL");user=System.getenv("INTEGRATION_DB_USER");password=System.getenv("INTEGRATION_DB_PASSWORD");
        schema="test_"+java.util.UUID.randomUUID().toString().replace("-","");
        try(var c=DriverManager.getConnection(url,user,password);var s=c.createStatement()){s.execute("CREATE SCHEMA "+schema);}
        store=new Store(url+(url.contains("?")?"&":"?")+"currentSchema="+schema,user,password);store.initialize();store.setup("admin","Administrador","PruebaSegura123");store.login("admin","PruebaSegura123");Samples.demo(store);link=store.links().getFirst();
    }
    @BeforeEach void reset()throws Exception {
        store.login("admin","PruebaSegura123");try(var c=store.open();var q=c.prepareStatement("DELETE FROM producto_homologado WHERE producto_id=?")){q.setLong(1,link.productId());q.executeUpdate();}var p=store.product(link.productId());store.saveProduct(new Store.Product(p.id(),p.code(),p.name(),p.brand(),p.model(),p.presentation(),p.capacity(),p.category(),p.keywords(),new BigDecimal("80"),new BigDecimal("120"),true));
    }
    @AfterAll void cleanup()throws Exception {if(schema!=null)try(var c=DriverManager.getConnection(url,user,password);var s=c.createStatement()){s.execute("DROP SCHEMA "+schema+" CASCADE");}}
    long capture(String price)throws Exception {new Scraper(store,(s,u)->new Extractor.Quote("Producto demostración 1 L",new BigDecimal(price),u,"Dato controlado de prueba")).run(link);return store.candidates(link.productId()).getFirst().id();}
    long confirmed(String price)throws Exception {long id=capture(price);store.validate(id,true,"Marca Demo, botella 1 L y condición verificadas en fixture");return id;}
    @Test void priceDecisionsAreAtomicAndPreserveHistoricalComparison()throws Exception {
        long candidate=confirmed("105");store.compare(candidate);
        long alert=store.alerts().stream().filter(a->{try{return store.alertDetail(a.id()).external().compareTo(new BigDecimal("105"))==0&&store.alertDetail(a.id()).decision()==null;}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow().id();
        assertThrows(IllegalStateException.class,()->store.decidePrice(alert,PriceDecision.Action.MATCH,null,new BigDecimal("119"),new BigDecimal("80"),"stale"));
        assertThrows(IllegalArgumentException.class,()->store.decidePrice(alert,PriceDecision.Action.LOWER,new BigDecimal("105"),new BigDecimal("120"),new BigDecimal("80"),"invalid"));
        assertNull(store.alertDetail(alert).decision());assertEquals(new BigDecimal("120.00"),store.product(link.productId()).price());
        var saved=store.decidePrice(alert,PriceDecision.Action.MATCH,null,new BigDecimal("120"),new BigDecimal("80"),"Igualar precio");
        assertEquals(new BigDecimal("25.00"),saved.profit());assertEquals(new BigDecimal("105.00"),store.product(link.productId()).price());
        var detail=store.alertDetail(alert);assertEquals(new BigDecimal("120.00"),detail.own());assertEquals("ATENDIDA",detail.status());assertEquals(saved.profit(),detail.decision().profit());assertEquals(new BigDecimal("120.00"),detail.decision().before());
        assertThrows(IllegalStateException.class,()->store.decidePrice(alert,PriceDecision.Action.KEEP,null,new BigDecimal("105"),new BigDecimal("80"),"duplicate"));
    }
    @Test void sourceSelectionAndProductBatchKeepFailuresIsolated()throws Exception {
        var preview=PlazaVeaImporterTest.preview();String token=java.util.UUID.randomUUID().toString().substring(0,8);
        long product=store.importReference(preview,new Store.Product(0,"BATCH-"+token,preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"gloria",new BigDecimal("4"),preview.price(),true),"Precio propio revisado");
        for(String name:List.of("fallo","ok","vacio","excluida"))store.saveSource(new Store.Source(0,name+token,"https://"+name+token+".example/","","","","","AUTO",60,24,true));
        var sources=store.sources().stream().filter(f->f.name().endsWith(token)).toList();var ids=sources.stream().filter(f->!f.name().startsWith("excluida")).map(Store.Source::id).collect(java.util.stream.Collectors.toSet());
        store.selectProductSources(product,ids,false);
        assertThrows(IllegalArgumentException.class,()->store.selectProductSources(product,Set.of(Long.MAX_VALUE),false));assertEquals(3,store.links().stream().filter(l->l.productId()==product&&!l.reference()&&l.active()).count());
        var batch=new ProductScraping(store,(f,u)->{throw new AssertionError("Se esperaba búsqueda automática");},(p,url)->{
            if(url.contains("fallo"))throw new java.io.IOException("Falla controlada");
            var quotes=url.contains("vacio")?List.<Extractor.Quote>of():List.of(new Extractor.Quote(p.name(),new BigDecimal("5.30"),url+"producto/p","Fixture"));
            return new SearchService.Result(p.name(),quotes,List.of(url),2,List.of());
        }).run(product);
        assertEquals(3,batch.sources().size());assertEquals(1,batch.candidates().size());assertTrue(batch.sources().stream().anyMatch(r->r.state().equals("ERROR")));assertTrue(batch.sources().stream().anyMatch(r->r.state().equals("SIN RESULTADOS")));assertTrue(batch.candidates().getFirst().source().startsWith("ok"));assertEquals("PENDIENTE",batch.candidates().getFirst().status());
        store.selectProductSources(product,Set.of(),false);assertThrows(IllegalArgumentException.class,()->new ProductScraping(store,new Extractor(),new SearchService()).run(product));assertEquals(1,store.candidates(product).size());assertTrue(store.links().stream().anyMatch(l->l.productId()==product&&l.reference()&&l.active()));assertTrue(store.links().stream().anyMatch(l->l.id()==link.id()&&l.active()));
    }
    @Test @Timeout(60) void localStoreCrudScrapingAndAlerts()throws Exception {
        var builder=new ProcessBuilder("node",Path.of("tienda-pruebas/server.mjs").toAbsolutePath().toString());
        builder.environment().put("TIENDA_PORT","0");builder.environment().put("TIENDA_EMPTY","true");builder.environment().put("TIENDA_DATA_FILE",dir.resolve("tienda-integracion/productos.json").toString());builder.redirectErrorStream(true);
        var server=builder.start();try(var output=server.inputReader()){
            String line=java.util.concurrent.CompletableFuture.supplyAsync(()->{try{return output.readLine();}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}).get(8,java.util.concurrent.TimeUnit.SECONDS);
            assertNotNull(line);assertTrue(line.startsWith("Tienda de pruebas: "),line);String origin=line.substring("Tienda de pruebas: ".length());
            var client=java.net.http.HttpClient.newBuilder().connectTimeout(java.time.Duration.ofSeconds(3)).build();
            String token=org.jsoup.Jsoup.connect(origin+"/admin/productos/nuevo").get().selectFirst("input[name=_csrf]").attr("value");
            var preview=PlazaVeaImporterTest.preview();var values=new LinkedHashMap<String,String>();values.put("_csrf",token);values.put("name",preview.title());values.put("brand",preview.brand());values.put("presentation",preview.presentation());values.put("capacity",preview.capacity());values.put("price","5.30");
            assertEquals(303,postShop(client,origin+"/admin/productos/nuevo",values).statusCode());
            String localProduct=org.jsoup.Jsoup.connect(origin).get().selectFirst("a[href^=/producto/]").absUrl("href");String localId=java.net.URI.create(localProduct).getPath().substring("/producto/".length());
            long product=store.importReference(preview,new Store.Product(0,"LOCAL-"+java.util.UUID.randomUUID().toString().substring(0,8),preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"",new BigDecimal("4.00"),preview.price(),true),"Referencia propia controlada de prueba");
            store.saveSource(new Store.Source(0,"Tienda integración",origin+"/","","","","","AUTO",60,24,true));long source=store.sources().stream().filter(f->f.url().equals(origin+"/")).findFirst().orElseThrow().id();store.selectProductSources(product,Set.of(source),false);
            var controller=new MonitoringController(store,new Extractor(),new SearchService());int before=store.alerts().size();var first=controller.extract(product);assertEquals(1,first.candidates().size());var candidate=first.candidates().getFirst();assertEquals(new BigDecimal("5.30"),candidate.price());assertEquals("PENDIENTE",candidate.status());assertEquals(before,store.alerts().size());assertTrue(controller.confirmAndCompare(candidate.id(),"Marca, presentación y capacidad coinciden; precio local de prueba").lower());assertEquals(before,store.alerts().size());assertEquals(1,store.homologated(product,source).size());assertTrue(store.monitoringSettings().get(product).scheduled());
            store.initialize();var reopened=new Store(url+(url.contains("?")?"&":"?")+"currentSchema="+schema,user,password);reopened.login("admin","PruebaSegura123");assertEquals(new BigDecimal("5.30"),reopened.homologated(product,source).getFirst().price());
            var unchanged=controller.extract(product);assertEquals("CONFIRMADO",unchanged.candidates().getFirst().status());assertEquals(before,store.alerts().size());
            values.put("price","7.00");assertEquals(303,postShop(client,origin+"/admin/productos/"+localId+"/editar",values).statusCode());var second=controller.extract(product);assertEquals(new BigDecimal("7.00"),second.candidates().getFirst().price());assertEquals("CONFIRMADO",second.candidates().getFirst().status());assertFalse(second.candidates().getFirst().comparison().result().lower());assertEquals(before+1,store.alerts().size());assertEquals("SUBIDA_PRECIO",store.alerts().getFirst().type());
            var change=store.alertDetail(store.alerts().getFirst().id());assertEquals(new BigDecimal("5.30"),change.previousPrice());assertEquals(new BigDecimal("1.70"),change.priceChange());
            values.put("price","5.00");assertEquals(303,postShop(client,origin+"/admin/productos/"+localId+"/editar",values).statusCode());var lower=controller.extract(product);assertEquals("BAJADA_PRECIO",lower.candidates().getFirst().comparison().alertType());assertEquals(before+2,store.alerts().size());
            controller.extract(product);assertEquals(before+2,store.alerts().size());
            values.put("name",preview.title()+" Pack 6 unidades");assertEquals(303,postShop(client,origin+"/admin/productos/"+localId+"/editar",values).statusCode());var changed=controller.extract(product);assertEquals("PENDIENTE",changed.candidates().getFirst().status());assertEquals("REVISAR",store.homologated(product,source).getFirst().state());assertEquals(before+2,store.alerts().size());
            store.confirmAndCompare(changed.candidates().getFirst().id(),"Nueva presentación revisada y aprobada");assertEquals("ACTIVO",store.homologated(product,source).getFirst().state());assertEquals(before+2,store.alerts().size());
            assertEquals(303,postShop(client,origin+"/admin/productos/"+localId+"/eliminar",Map.of("_csrf",token)).statusCode());var empty=controller.extract(product);assertTrue(empty.candidates().isEmpty());assertEquals("ERROR",empty.sources().getFirst().state());assertEquals(6,store.candidates(product).size());
        }finally{server.destroy();if(!server.waitFor(3,java.util.concurrent.TimeUnit.SECONDS)){server.destroyForcibly();server.waitFor(3,java.util.concurrent.TimeUnit.SECONDS);}}
    }
    private static java.net.http.HttpResponse<String> postShop(java.net.http.HttpClient client,String url,Map<String,String> values)throws Exception {
        String body=values.entrySet().stream().map(e->java.net.URLEncoder.encode(e.getKey(),java.nio.charset.StandardCharsets.UTF_8)+"="+java.net.URLEncoder.encode(e.getValue(),java.nio.charset.StandardCharsets.UTF_8)).collect(java.util.stream.Collectors.joining("&"));
        return client.send(java.net.http.HttpRequest.newBuilder(java.net.URI.create(url)).timeout(java.time.Duration.ofSeconds(8)).header("Content-Type","application/x-www-form-urlencoded").POST(java.net.http.HttpRequest.BodyPublishers.ofString(body)).build(),java.net.http.HttpResponse.BodyHandlers.ofString());
    }
    @Test void editableRolesEnforceModulesAndPreserveChanges()throws Exception {
        String token=java.util.UUID.randomUUID().toString().substring(0,8);String analyst="analista_"+token;
        store.saveUser(0,analyst,"Analista","AnalistaClave123","ANALISTA",true);store.login(analyst,"AnalistaClave123");
        assertEquals(Set.of(Module.PRODUCTOS,Module.EXTRACCION,Module.ALERTAS),store.permissions());
        store.saveProduct(new Store.Product(0,"AN-"+token,"Producto analista","Marca","","Botella","1 L","General","",BigDecimal.ONE,BigDecimal.TEN,true));
        var created=store.products().stream().filter(p->p.code().equals("AN-"+token)).findFirst().orElseThrow();assertThrows(SecurityException.class,()->store.saveProduct(created));assertThrows(SecurityException.class,()->store.saveRole("PRUEBA","Prueba",true,Set.of(Module.ALERTAS)));assertThrows(SecurityException.class,()->store.selectProductSources(created.id(),Set.of(),false));
        store.login("admin","PruebaSegura123");String role="ROL_"+token.toUpperCase(Locale.ROOT);store.saveRole(role,"Alertas",true,Set.of(Module.ALERTAS));store.saveUser(0,"lector_"+token,"Lector","LectorClave123",role,true);store.initialize();assertEquals(Set.of(Module.ALERTAS),store.roles().stream().filter(r->r.code().equals(role)).findFirst().orElseThrow().modules());
        store.login("lector_"+token,"LectorClave123");assertThrows(SecurityException.class,()->new ProductScraping(store,new Extractor(),new SearchService()).run(link.productId()));assertThrows(SecurityException.class,()->store.saveSource(store.source(link.sourceId())));
        store.login("admin","PruebaSegura123");store.saveRole(role,"Productos",true,Set.of(Module.PRODUCTOS));store.login("lector_"+token,"LectorClave123");assertEquals(Set.of(Module.PRODUCTOS),store.permissions());assertThrows(SecurityException.class,()->store.attend(1,"ATENDIDA","Observación"));store.login("admin","PruebaSegura123");assertThrows(IllegalArgumentException.class,()->store.saveRole("ADMIN","Admin",true,Set.of(Module.PRODUCTOS)));
    }
    @Test void productFrequencyAndSingleSourceComparisonsAreIndependent()throws Exception {
        var preview=PlazaVeaImporterTest.preview();String token=java.util.UUID.randomUUID().toString().substring(0,8);
        long first=store.importReference(preview,new Store.Product(0,"F1-"+token,preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"",new BigDecimal("4"),preview.price(),true),"Referencia");
        long second=store.importReference(preview,new Store.Product(0,"F2-"+token,preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"",new BigDecimal("4"),preview.price(),true),"Referencia");
        store.saveSource(new Store.Source(0,"A"+token,"https://a"+token+".example/","","","","","AUTO",60,24,true));store.saveSource(new Store.Source(0,"B"+token,"https://b"+token+".example/","","","","","AUTO",60,24,true));
        var ids=store.sources().stream().filter(f->f.name().endsWith(token)).map(Store.Source::id).collect(java.util.stream.Collectors.toSet());long a=ids.stream().min(Long::compare).orElseThrow();store.selectProductSources(first,ids,true,1);store.selectProductSources(second,ids,true,7);
        assertEquals(1,store.monitoringSettings().get(first).minutes());assertEquals(7,store.monitoringSettings().get(second).minutes());assertThrows(IllegalArgumentException.class,()->store.selectProductSources(first,ids,true,0));
        var requested=new ArrayList<String>();ISearchFuente search=(product,url)->{requested.add(url);return new SearchService.Result(product.name(),List.of(new Extractor.Quote(product.name(),new BigDecimal("5.30"),url+"producto/p","Fixture")),List.of(url),2,List.of());};var runner=new ProductScraping(store,new Extractor(),search);
        var only=runner.run(first,a);assertEquals(1,requested.size());assertEquals(1,only.sources().size());assertTrue(only.candidates().stream().allMatch(c->c.sourceId()==a));requested.clear();var all=runner.run(first);assertEquals(2,requested.size());assertEquals(2,all.sources().size());assertThrows(IllegalArgumentException.class,()->runner.run(first,Long.MAX_VALUE));
        var ownLink=store.links().stream().filter(l->l.productId()==first&&l.sourceId()==a).findFirst().orElseThrow();
        try(var c=store.open();var q=c.prepareStatement("SELECT EXTRACT(epoch FROM proxima_ejecucion-CURRENT_TIMESTAMP) FROM producto_fuente WHERE id=?")){q.setLong(1,ownLink.id());try(var r=q.executeQuery()){r.next();assertTrue(r.getDouble(1)>45&&r.getDouble(1)<=60);}}
        int alerts=store.alerts().size();store.confirmAndCompare(only.candidates().getFirst().id(),"Misma marca capacidad y presentación");assertEquals(alerts,store.alerts().size());assertEquals(new BigDecimal("5.30"),store.homologated(first,a).getFirst().price());
    }
    @Test void CP01_registerAndPersist()throws Exception {assertEquals(0,new BigDecimal("80").compareTo(store.product(link.productId()).cost()));assertFalse(store.sources().isEmpty());}
    @Test void CP02_rejectNegativeCost()throws Exception {var p=store.product(link.productId());assertThrows(IllegalArgumentException.class,()->store.saveProduct(new Store.Product(0,"INVALIDO","Producto","Demo","","Botella","1 L","General","",new BigDecimal("-1"),BigDecimal.TEN,true)));}
    @Test void CP03_lowerCompetitor()throws Exception {var r=store.compare(confirmed("105"));assertEquals(new BigDecimal("23.81"),r.simulatedMargin());assertTrue(r.lower());assertTrue(store.alerts().stream().anyMatch(a->a.type().equals("PRECIO_INFERIOR")));}
    @Test void CP04_higherCompetitor()throws Exception {int count=store.alerts().size();assertFalse(store.compare(confirmed("130")).lower());assertEquals(count,store.alerts().size());}
    @Test void CP05_loss()throws Exception {assertTrue(store.compare(confirmed("70")).loss());assertTrue(store.alerts().stream().anyMatch(a->a.type().equals("PERDIDA")));}
    @Test void confirmAndCompareCreatesAlertAtomicallyAndIsRepeatSafe()throws Exception {
        long id=capture("105");int alerts=store.alerts().size();var result=store.confirmAndCompare(id,"Marca, botella 1 L y condición verificadas");assertTrue(result.lower());assertEquals(alerts,store.alerts().size());assertEquals(1,store.homologated(link.productId(),link.sourceId()).size());
        var row=store.candidates(link.productId()).stream().filter(c->c.id()==id).findFirst().orElseThrow();assertEquals("CONFIRMADO",row.status());assertNotNull(row.comparison());assertEquals("SIN_ALERTA",row.comparison().alertType());assertEquals(0,new BigDecimal("120").compareTo(row.comparison().own()));
        store.confirmAndCompare(id,"");assertEquals(alerts,store.alerts().size());
    }
    @Test void failedComparisonRollsBackConfirmation()throws Exception {
        long id=capture("105");try(var c=store.open();var s=c.prepareStatement("UPDATE resultado SET fecha=CURRENT_TIMESTAMP-interval '8 days' WHERE id=?")){s.setLong(1,id);s.executeUpdate();}
        assertThrows(IllegalArgumentException.class,()->store.confirmAndCompare(id,"Revisión de candidato vencido"));assertEquals("PENDIENTE",store.candidates(link.productId()).stream().filter(r->r.id()==id).findFirst().orElseThrow().status());
        try(var c=store.open();var s=c.prepareStatement("SELECT count(*) FROM homologacion WHERE resultado_id=?")){s.setLong(1,id);try(var r=s.executeQuery()){r.next();assertEquals(0,r.getInt(1));}}
    }
    @Test void unifiedComparisonDoesNotAlertOnHigherPriceAndWarnsOnLoss()throws Exception {
        int alerts=store.alerts().size();long higher=capture("130");assertFalse(store.confirmAndCompare(higher,"Misma presentación, precio mayor").lower());assertEquals(alerts,store.alerts().size());
        long loss=capture("70");assertTrue(store.confirmAndCompare(loss,"Misma presentación, revisar pérdida al igualar").loss());assertEquals(alerts+1,store.alerts().size());assertEquals("BAJADA_PRECIO",store.alerts().getFirst().type());
    }
    @Test void CP06_rejectDifferentPresentation()throws Exception {long id=capture("105");assertThrows(IllegalArgumentException.class,()->store.compare(id));store.validate(id,false,"La ficha contiene 500 ml y el producto propio 1 L");assertThrows(IllegalArgumentException.class,()->store.compare(id));}
    @Test void CP07_timeoutPreservesHistory()throws Exception {int before=store.report(ReportType.HISTORIAL,ReportFilter.all()).rows().size();assertThrows(java.net.SocketTimeoutException.class,()->new Scraper(store,(s,u)->{throw new java.net.SocketTimeoutException("Timeout controlado");}).run(link));assertEquals(before,store.report(ReportType.HISTORIAL,ReportFilter.all()).rows().size());var report=store.report(ReportType.EJECUCIONES,ReportFilter.all());assertTrue(report.rows().stream().anyMatch(r->r.contains("ERROR")));}
    @Test void snapshotsAndDuplicates()throws Exception {long id=confirmed("105");store.compare(id);var p=store.product(link.productId());store.saveProduct(new Store.Product(p.id(),p.code(),p.name(),p.brand(),p.model(),p.presentation(),p.capacity(),p.category(),p.keywords(),new BigDecimal("90"),new BigDecimal("125"),true));try(var c=store.open();var s=c.prepareStatement("SELECT costo,propio FROM comparacion WHERE resultado_id=?")){s.setLong(1,id);try(var r=s.executeQuery()){assertTrue(r.next());assertEquals(0,new BigDecimal("80").compareTo(r.getBigDecimal(1)));assertEquals(0,new BigDecimal("120").compareTo(r.getBigDecimal(2)));}}assertThrows(IllegalStateException.class,()->store.compare(id));}
    @Test void expiry()throws Exception {long id=confirmed("105");try(var c=store.open();var s=c.prepareStatement("UPDATE resultado SET fecha=CURRENT_TIMESTAMP-interval '8 days' WHERE id=?")){s.setLong(1,id);s.executeUpdate();}assertThrows(IllegalArgumentException.class,()->store.compare(id));}
    @Test void authorizationAndAuditedAttention()throws Exception {
        store.compare(confirmed("105"));var alert=store.alerts().getFirst();store.attend(alert.id(),"ATENDIDA","Se conserva el precio propio tras revisar margen");assertTrue(store.alerts().stream().anyMatch(a->a.id()==alert.id()&&a.status().equals("ATENDIDA")));
        if(store.users().stream().noneMatch(u->u.username().equals("analista")))store.saveUser(0,"analista","Analista","AnalistaClave123","ANALISTA",true);
        store.login("analista","AnalistaClave123");assertFalse(store.session().admin());assertThrows(SecurityException.class,()->store.saveSource(store.source(link.sourceId())));assertFalse(store.products().isEmpty());store.logout();assertThrows(SecurityException.class,store::products);
    }
    @Test void reportsAndFilters()throws Exception {store.compare(confirmed("105"));for(var type:ReportType.values())assertNotNull(store.report(type,ReportFilter.all()));var filter=new ReportFilter(link.productId(),link.sourceId(),LocalDate.now(ZoneId.of("America/Lima")).minusDays(1),LocalDate.now(ZoneId.of("America/Lima")));var data=store.report(ReportType.COMPARACIONES,filter);assertFalse(data.rows().isEmpty());var path=dir.resolve("comparaciones.pdf");Reports.pdf(data,path);store.recordExport(ReportType.COMPARACIONES,filter,path.toString());assertFalse(store.report(ReportType.EXPORTACIONES,ReportFilter.all()).rows().isEmpty());assertThrows(IllegalArgumentException.class,()->store.report(ReportType.HISTORIAL,new ReportFilter(0,0,LocalDate.now(),LocalDate.now().minusDays(1))));}
    @Test void idempotentMigration()throws Exception {int count=store.products().size();store.initialize();assertEquals(count,store.products().size());assertThrows(IllegalStateException.class,()->store.setup("otro","Otro","OtraClave12345"));}
    @Test void usernameLoginDoesNotRequireEmail()throws Exception {
        String username="operador_"+java.util.UUID.randomUUID().toString().substring(0,8);
        store.saveUser(0,username,"Operador","OperadorClave123","ANALISTA",true);
        assertEquals(username,store.login(username.toUpperCase(java.util.Locale.ROOT),"OperadorClave123").username());
        assertThrows(IllegalArgumentException.class,()->store.login("operador@example.com","OperadorClave123"));
        store.login("admin","PruebaSegura123");assertThrows(IllegalArgumentException.class,()->store.saveUser(0,"usuario con espacios","Inválido","OtraClave12345","ANALISTA",true));
    }
    @Test void legacyAccountsKeepPasswordsAndGetUniqueUsernames()throws Exception {
        String legacy="legacy_"+java.util.UUID.randomUUID().toString().replace("-","");
        try(var c=DriverManager.getConnection(url,user,password);var s=c.createStatement()){s.execute("CREATE SCHEMA "+legacy);}
        var oldStore=new Store(url+(url.contains("?")?"&":"?")+"currentSchema="+legacy,user,password);
        try{
            try(var c=oldStore.open();var s=c.createStatement()){
                for(String resource:java.util.List.of("/schema.sql","/migration-v2.sql","/migration-v3.sql","/migration-v4.sql"))try(var in=Store.class.getResourceAsStream(resource)){s.execute(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));}
                try(var insert=c.prepareStatement("INSERT INTO usuario(correo,nombre,password_hash,rol) VALUES (?,?,?,'ADMIN')")){
                    for(String email:java.util.List.of("operador@uno.example","operador@dos.example")){insert.setString(1,email);insert.setString(2,"Usuario existente");insert.setString(3,Passwords.hash("ConservarClave123"));insert.executeUpdate();}
                }
            }
            oldStore.initialize();assertEquals("operador",oldStore.login("operador","ConservarClave123").username());assertEquals("operador_2",oldStore.login("operador_2","ConservarClave123").username());oldStore.initialize();assertEquals("operador_2",oldStore.login("operador_2","ConservarClave123").username());
        }finally{try(var c=DriverManager.getConnection(url,user,password);var s=c.createStatement()){s.execute("DROP SCHEMA "+legacy+" CASCADE");}}
    }
    @Test void isolatedConfiguredSchemaDoesNotUsePublicTables()throws Exception {
        String isolated="app_"+java.util.UUID.randomUUID().toString().replace("-","");var configured=new Store(new Config.Database(url,user,password,5,15,isolated));
        try{assertTrue(configured.testConnection().contains(isolated));configured.initialize();assertTrue(configured.needsSetup());try(var c=configured.open();var s=c.createStatement();var r=s.executeQuery("SELECT current_schema()")){r.next();assertEquals(isolated,r.getString(1));}}
        finally{try(var c=DriverManager.getConnection(url,user,password);var s=c.createStatement()){s.execute("DROP SCHEMA IF EXISTS "+isolated+" CASCADE");}}
    }
    @Test void disabledLinkAndSchedule()throws Exception {store.saveLink(link.id(),link.productId(),link.sourceId(),link.url(),link.condition(),true,false);try{assertThrows(IllegalArgumentException.class,()->new Scraper(store).run(link));assertTrue(store.dueLinks().stream().noneMatch(l->l.id()==link.id()));}finally{store.saveLink(link.id(),link.productId(),link.sourceId(),link.url(),link.condition(),false,true);}}
    @Test void scheduledRunAdvancesNextExecution()throws Exception {
        store.confirmAndCompare(capture("105"),"Misma marca y presentación, activar seguimiento");
        store.saveLink(link.id(),link.productId(),link.sourceId(),link.url(),link.condition(),true,true);
        try {try(var c=store.open();var s=c.createStatement()){s.execute("UPDATE producto_fuente SET proxima_ejecucion=CURRENT_TIMESTAMP-interval '1 minute' WHERE id="+link.id());}
            assertTrue(store.dueLinks().stream().anyMatch(l->l.id()==link.id()));new Scraper(store).run(link);assertTrue(store.dueLinks().stream().noneMatch(l->l.id()==link.id()));
        }finally{store.saveLink(link.id(),link.productId(),link.sourceId(),link.url(),link.condition(),false,true);}
    }
    @Test void plazaVeaUrlCreatesOwnReferenceAndKeepsBpmnReview()throws Exception {
        var preview=PlazaVeaImporterTest.preview();String code=preview.code()+"-"+java.util.UUID.randomUUID().toString().substring(0,8);
        var own=new Store.Product(0,code,preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"gloria,leche",new BigDecimal("4.00"),preview.price(),true);
        long product=store.importReference(preview,own,"Precio web individual; condiciones verificadas");var reference=store.links().stream().filter(l->l.productId()==product&&l.reference()).findFirst().orElseThrow();
        assertTrue(store.candidates(product).isEmpty());assertThrows(IllegalArgumentException.class,()->new Scraper(store).run(reference));assertEquals(0,store.product(product).price().compareTo(preview.price()));
        assertThrows(IllegalArgumentException.class,()->store.configureMonitoring(product,store.source(reference.sourceId()),preview.url(),"Precio propio",false));
        var config=new Store.Source(0,"Fuente externa","https://externa.example","h1",".precio","","","CSS",60,24,true);store.configureMonitoring(product,config,"https://externa.example/producto/p","Precio web regular",false);
        var external=store.links().stream().filter(l->l.productId()==product&&!l.reference()).findFirst().orElseThrow();
        new Scraper(store,(s,u)->new Extractor.Quote(preview.title(),new BigDecimal("5.30"),u,"Fixture externo")).run(external);
        var candidate=store.candidates(product).getFirst();assertEquals("PENDIENTE",candidate.status());assertThrows(IllegalArgumentException.class,()->store.compare(candidate.id()));
        store.validate(candidate.id(),true,"Marca, caja 946 ml y condición verificadas");assertTrue(store.compare(candidate.id()).lower());
        assertFalse(store.report(ReportType.REFERENCIAS,new ReportFilter(product,0,null,null)).rows().isEmpty());
        var refreshed=new PlazaVeaImporter.Preview(preview.code(),preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),preview.sku(),preview.ean(),new BigDecimal("7.20"),preview.url(),preview.captured().plusSeconds(1),preview.evidence(),preview.warnings());
        store.importReference(refreshed,new Store.Product(product,code,own.name(),own.brand(),own.model(),own.presentation(),own.capacity(),own.category(),own.keywords(),own.cost(),refreshed.price(),true),"Actualización explícita del precio propio");
        var report=store.report(ReportType.COMPARACIONES,new ReportFilter(product,0,null,null));int ownColumn=report.columns().indexOf("propio");assertEquals("6.10",report.rows().getFirst().get(ownColumn));
    }
    @Test void automaticSiteSearchPersistsMultiplePendingCandidatesAndEmptyRuns()throws Exception {
        var preview=PlazaVeaImporterTest.preview();long product=store.importReference(preview,new Store.Product(0,"SEARCH-"+java.util.UUID.randomUUID().toString().substring(0,8),preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"gloria,leche",new BigDecimal("4"),preview.price(),true),"Precio propio revisado");
        var searchLink=store.configureSearch(product,"https://busqueda.example/",60,24,false);assertTrue(searchLink.search());
        var found=new SearchService.Result("Leche GLORIA",java.util.List.of(new Extractor.Quote(preview.title(),new BigDecimal("5.30"),"https://busqueda.example/uno/p","Búsqueda de prueba"),new Extractor.Quote("Leche GLORIA Caja 500ml",new BigDecimal("3.20"),"https://busqueda.example/dos/p","Búsqueda de prueba")),java.util.List.of("https://busqueda.example/buscar?q=gloria"),4,java.util.List.of());
        var outcome=new Scraper(store,new Extractor(),(p,u)->found).run(searchLink);assertEquals(2,outcome.candidates());var candidates=store.candidatesForRun(product,outcome.executionId());assertEquals(2,candidates.size());assertTrue(candidates.stream().allMatch(c->c.status().equals("PENDIENTE")));assertThrows(IllegalArgumentException.class,()->store.compare(candidates.getFirst().id()));
        var empty=new SearchService.Result("Leche GLORIA",java.util.List.of(),java.util.List.of(),1,java.util.List.of("Sin coincidencias verificables"));var noResults=new Scraper(store,new Extractor(),(p,u)->empty).run(searchLink);assertEquals(0,noResults.candidates());assertTrue(store.candidatesForRun(product,noResults.executionId()).isEmpty());assertEquals(2,store.candidates(product).size());
        var report=store.report(ReportType.EJECUCIONES,new ReportFilter(product,0,null,null));assertTrue(report.rows().stream().anyMatch(r->r.contains("SIN_RESULTADOS")));store.initialize();assertEquals(2,store.candidates(product).size());
    }
    @Test @EnabledIfEnvironmentVariable(named="LIVE_TESTS",matches="true") void realPlazaVeaEndToEnd()throws Exception {
        Samples.realPages(store);var real=store.links().stream().filter(l->l.url().equals(Samples.PLAZA_URL)&&!l.reference()).findFirst().orElseThrow();new Scraper(store).run(real);var candidate=store.candidates(real.productId()).getFirst();assertTrue(candidate.title().toUpperCase().contains("GLORIA"));assertTrue(candidate.price().signum()>0);assertTrue(candidate.url().startsWith("https://www.plazavea.com.pe/"));
        // Test validates the configured 946 ml example; production still requires the human reviewer.
        assertTrue(candidate.title().contains("946"));store.validate(candidate.id(),true,"Prueba viva: título GLORIA Entera UHT Caja 946ml coincide con el ejemplo. Costo y precio propio son de prueba.");store.compare(candidate.id());
        var data=store.report(ReportType.COMPARACIONES,new ReportFilter(real.productId(),real.sourceId(),null,null));assertEquals(1,data.rows().size());Files.createDirectories(Path.of("artifacts"));Reports.csv(data,Path.of("artifacts","prueba-real.csv"));Reports.pdf(data,Path.of("artifacts","prueba-real.pdf"));
        System.out.println("PRUEBA REAL: "+candidate.title()+" | PEN "+candidate.price()+" | "+candidate.date()+" | "+candidate.url());
        var makro=store.links().stream().filter(l->l.url().equals(Samples.MAKRO_URL)).findFirst().orElseThrow();new Scraper(store).run(makro);var other=store.candidates(makro.productId()).getFirst();assertTrue(other.title().contains("946"));assertTrue(other.price().signum()>0);store.validate(other.id(),true,"Prueba viva de segunda fuente: GLORIA Entera UHT Caja 946ml; verificar condiciones de canal. Valores propios de prueba.");store.compare(other.id());
        var both=store.report(ReportType.COMPARACIONES,new ReportFilter(real.productId(),0,null,null));assertEquals(2,both.rows().size());Reports.csv(both,Path.of("artifacts","prueba-real.csv"));Reports.pdf(both,Path.of("artifacts","prueba-real.pdf"));
        System.out.println("PRUEBA REAL MAKRO: "+other.title()+" | PEN "+other.price()+" | "+other.url());
        try(var pdf=org.apache.pdfbox.Loader.loadPDF(Path.of("artifacts","prueba-real.pdf").toFile())){
            var renderer=new org.apache.pdfbox.rendering.PDFRenderer(pdf);
            javax.imageio.ImageIO.write(renderer.renderImageWithDPI(0,110),"png",Path.of("artifacts","reporte-real-vista.png").toFile());
        }
    }
    @Test @EnabledIfEnvironmentVariable(named="LIVE_TESTS",matches="true") void realImportFromPlazaVeaUrl()throws Exception {
        var preview=new PlazaVeaImporter().inspect(Samples.PLAZA_URL);assertTrue(preview.title().contains("GLORIA"));assertFalse(preview.brand().isBlank());assertEquals("Caja",preview.presentation());
        long product=store.importReference(preview,new Store.Product(0,preview.code()+"-LIVE",preview.title(),preview.brand(),preview.model(),preview.presentation(),preview.capacity(),preview.category(),"gloria,leche",new BigDecimal("4.00"),preview.price(),true),"Captura de prueba viva; verificar ubicación y condiciones");
        assertTrue(store.links().stream().anyMatch(l->l.productId()==product&&l.reference()));
        var report=store.report(ReportType.REFERENCIAS,new ReportFilter(product,0,null,null));Reports.csv(report,Path.of("artifacts","importacion-plazavea-real.csv"));Reports.pdf(report,Path.of("artifacts","importacion-plazavea-real.pdf"));
        System.out.println("IMPORTACION PLAZA VEA: "+preview.title()+" | PEN "+preview.price()+" | SKU "+preview.sku()+" | advertencias="+preview.warnings().size());
    }
}

