package pe.edu.monitoreo;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
class PriceDecisionTest {
 private static BigDecimal n(String v){return new BigDecimal(v);}
 @Test void previewsKeepMatchAndLowerWithGrossProfit(){
  var keep=PriceDecision.simulate(PriceDecision.Action.KEEP,n("80"),n("120"),n("105"),null);
  assertEquals(n("40.00"),keep.profit());assertEquals(n("33.33"),keep.margin());
  var match=PriceDecision.simulate(PriceDecision.Action.MATCH,n("80"),n("120"),n("105"),null);
  assertEquals(n("25.00"),match.profit());assertEquals(n("23.81"),match.margin());
  var lower=PriceDecision.simulate(PriceDecision.Action.LOWER,n("80"),n("120"),n("105"),n("79.90"));
  assertEquals(n("-0.10"),lower.profit());assertTrue(lower.loss());
 }
 @Test void rejectsInvalidOrNonLowerTargets(){
  for(String target:new String[]{"0","-1","105","106","104.999"})
   assertThrows(IllegalArgumentException.class,()->PriceDecision.simulate(PriceDecision.Action.LOWER,n("80"),n("120"),n("105"),n(target)));
 }
}
