package pe.edu.monitoreo;
import java.math.*;
/** Validates a commercial price decision and calculates its effect before persistence. */
public final class PriceDecision {
 public enum Action {KEEP("Mantener precio"),MATCH("Igualar competencia"),LOWER("Precio menor");private final String label;Action(String label){this.label=label;}@Override public String toString(){return label;}}
 public record Simulation(BigDecimal price,BigDecimal profit,BigDecimal margin,boolean loss){}
 private PriceDecision(){}
 public static Simulation simulate(Action action,BigDecimal cost,BigDecimal current,BigDecimal competitor,BigDecimal proposed){
  if(action==null)throw new IllegalArgumentException("Selecciona una decisión.");
  BigDecimal target=switch(action){case KEEP->current;case MATCH->competitor;case LOWER->proposed;};
  if(target==null)throw new IllegalArgumentException("Ingresa el nuevo precio de venta.");
  try{target=target.setScale(2,RoundingMode.UNNECESSARY);}catch(ArithmeticException e){throw new IllegalArgumentException("El precio admite dos decimales.");}
  if(action==Action.LOWER&&target.compareTo(competitor)>=0)throw new IllegalArgumentException("El nuevo precio debe ser menor al de la competencia.");
  var result=Economics.compare(cost,current,target);return new Simulation(target,result.simulatedProfit(),result.simulatedMargin(),result.loss());
 }
}
